import 'package:flutter/material.dart';
import 'package:flutterapp/gp2appapp/generatedregistrologin1widget/GeneratedRegistroLogin1Widget.dart';
import 'package:flutterapp/gp2appapp/generatedregistrologin2widget1/GeneratedRegistroLogin2Widget1.dart';
import 'package:flutterapp/gp2appapp/generatedregistrologin3widget/GeneratedRegistroLogin3Widget.dart';
import 'package:flutterapp/gp2appapp/generateddashboardrwidget/GeneratedDashboardRWidget.dart';
import 'package:flutterapp/gp2appapp/generateddashboardgwidget/GeneratedDashboardGWidget.dart';
import 'package:flutterapp/gp2appapp/generateddashboardywidget/GeneratedDashboardYWidget.dart';

void main() {
  runApp(GP2appApp());
}

class GP2appApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/GeneratedRegistroLogin1Widget',
      routes: {
        '/GeneratedRegistroLogin1Widget': (context) =>
            GeneratedRegistroLogin1Widget(),
        '/GeneratedRegistroLogin2Widget1': (context) =>
            GeneratedRegistroLogin2Widget1(),
        '/GeneratedRegistroLogin3Widget': (context) =>
            GeneratedRegistroLogin3Widget(),
        '/GeneratedDashboardRWidget': (context) => GeneratedDashboardRWidget(),
        '/GeneratedDashboardGWidget': (context) => GeneratedDashboardGWidget(),
        '/GeneratedDashboardYWidget': (context) => GeneratedDashboardYWidget(),
      },
    );
  }
}
